
function makeTransfer() {
    const beneficiary = document.getElementById("beneficiary").value;
    const amount = document.getElementById("amount").value;
    const message = `Virement de ${amount}€ effectué vers ${beneficiary}.`;
    document.getElementById("confirmation").innerText = message;
}
